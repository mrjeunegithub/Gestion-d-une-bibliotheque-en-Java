package  exceptions;

public class AnneeInvalideException extends LivreException{
    public AnneeInvalideException(String message){
        super(message);
    }
    
}
