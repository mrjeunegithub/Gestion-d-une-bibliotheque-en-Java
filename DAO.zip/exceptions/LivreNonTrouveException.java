package  exceptions;

public class LivreNonTrouveException extends BaseDeDonneesException {
    public LivreNonTrouveException(String message) {
        super(message);
    }
}
